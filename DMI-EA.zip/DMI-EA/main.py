import sys
import os

print('Python %s on %s at %s' % (sys.version, sys.platform, os.getcwd()))
sys.path.extend(['./'])

from algorithms.DmiEA import DmiEA
from utils.get_arguments import get_args


def main():
    args, _ = get_args()
    DmiEA(args).run()


if __name__ == '__main__':
    main()
